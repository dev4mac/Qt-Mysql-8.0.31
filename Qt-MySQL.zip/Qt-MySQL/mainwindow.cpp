#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    DataBase = QSqlDatabase::addDatabase("QMYSQL");

    // Définition des paramètres de connexion à la base de données
    DataBase.setHostName("127.0.0.1"); // ip serveur MySQL
    DataBase.setDatabaseName("dev4mac"); // Nom de la base
    DataBase.setUserName("root"); // Nom utilisateur
    DataBase.setPassword("<password>"); // Mot de passe

    if(DataBase.open()) {
        qDebug() << "Connecté à la Base";
        }
        else {
            qDebug() << "Echec de la connexion";
        }

    }


MainWindow::~MainWindow()
{
    delete ui;
}
